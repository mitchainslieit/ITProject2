<?php require 'app/model/student-funct.php'; $run = new studentFunct ?>
	<div class="contentpage">
		<div class="row">	
			<div class="dashboardWidget" id="dashboard-calendar">
				<div class="cont2" style="border: 1px solid #ddd;">	
					<div class="header">
						<p>	
							<i class="far fa-calendar-alt fnt"></i>
							<span>Calendar</span>
						</p>
					</div>
					<div class="eventcontent">
						<div id="calendar"></div>
					</div>
				</div>
			</div>
		</div>	
	</div>