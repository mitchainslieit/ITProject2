				<div id="footer">
					<div class="row">
						<p class="copy">&copy 2019. Bakakeng National Highschool, Baguio City</p>
					</div>
				</div>
			</div>
		</div>
		<script src="<?php echo URL; ?>public/scripts/sitescripts.js" defer></script>
		<?php if( $this->siteInfo['cookie'] ): ?>
		<script src="//cdnjs.cloudflare.com/ajax/libs/cookieconsent2/3.0.3/cookieconsent.min.js"></script>
		<?php endif; ?>
	</body>
</html>


