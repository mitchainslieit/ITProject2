	<link rel="icon" href="public/images/favicon.png" type="image/x-icon">
	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/jquery-ui/jquery-ui.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/bootstrap/css/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/css/cookieconsent.min.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/css/all.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/css/fullcalendar.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/datatables/datatables.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/ambiance/jquery.ambiance.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/SweetDropDown/jquery.sweet-dropdown.min.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/tooltip/dist/css/tooltipster.bundle.min.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/tooltip/dist/css/plugins/tooltipster/sideTip/themes/tooltipster-sideTip-borderless.min.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/slick-1.8.1/slick/slick.css"/>
	<link href="<?php echo URL; ?>public/styles/style.css" rel="stylesheet" type="text/css">

	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/js/jquery-3.3.1.js"></script>
	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/jquery-ui/jquery-ui.js"></script>
	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/v/dt/jszip-2.5.0/dt-1.10.18/b-1.5.6/b-colvis-1.5.6/b-flash-1.5.6/b-html5-1.5.6/b-print-1.5.6/fc-3.2.5/fh-3.1.4/r-2.2.2/sc-2.0.0/datatables.min.js"></script>
	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/js/jquery.form-validator.min.js"></script>
	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/js/moment.min.js"></script>
	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/js/fullcalendar.min.js"></script>
	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/SweetDropDown/jquery.sweet-dropdown.min.js"></script>
	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/printThis/printThis.js"></script>
	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/ambiance/jquery.ambiance.js"></script>
	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/sweetalert/sweetalert.js"></script>
	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/google-chart/loader.js"></script>
	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/slick-1.8.1/slick/slick.min.js"></script>