# MVC
Static website implementing an MVC design
