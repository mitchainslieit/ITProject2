	<div class="contentpage" id="contentpage">
		<div class="row">
			<div class="widget">	
				<div class="header hclass">	
					<div class="cont">	
						<i class="fas fa-money-check"></i>
						<span>Fee Type</span>
					</div>
					<p>School Year: 2019-2020</p>
				</div>
				<div class="widgetContent">
					<div class="cont1">
						<button>Add a fee type <i class="fas fa-plus fnt"></i></button>
					</div>
					<div class="cont2">
						<table id="table" class="display">
							<thead>
								<tr>
									<th>Fee Type</th>
									<th>Amount</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>sample 1</td>
									<td>sample 2</td>
									<td>sample 3</td>
								</tr>
								<tr>
									<td>sample 1</td>
									<td>sample 2</td>
									<td>sample 3</td>
								</tr>
								<tr>
									<td>sample 1</td>
									<td>sample 2</td>
									<td>sample 3</td>
								</tr>
								<tr>
									<td>01</td>
									<td>English</td>
									<td>English1</td>
								</tr>
								<tr>
									<td>sample 1</td>
									<td>sample 2</td>
									<td>sample 3</td>
								</tr>
								<tr>
									<td>sample 1</td>
									<td>sample 2</td>
									<td>sample 3</td>
								</tr>
								<tr>
									<td>sample 1</td>
									<td>sample 2</td>
									<td>sample 3</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
