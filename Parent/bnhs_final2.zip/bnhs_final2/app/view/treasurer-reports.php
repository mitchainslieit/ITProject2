	<div class="contentpage">
		<div class="row">	
			<div class="widget">	
				<div class="header">	
					<p>	
						<i class="far fa-calendar-alt fnt"></i>
						<span>Attendance Report</span>
					</p>
					<p>School Year: 2019-2020</p>
				</div>	
				<div class="eventcontent">
					<div class="cont3">

						<div class="table-scroll">	
							<div class="table-wrap">	
								<table>
									<tr>
										<th>Day/Time</th>
										<th>Monday</th>   
									</tr>
									<tr>
										<td>Name: </td>
										<td>Tom C. Cruz</td>
									</tr>
									<tr>
										<td>Grade Level & Class: </td>
										<td>Grade 7 - Hope</td>
									</tr>
									<tr>
										<td>Number of Days Present: </td>
										<td><b><font color="green">20</font></b></td>
									</tr>
									<tr>
										<td>Number of Days Absent: </td>
										<td><b><font color="red">5</font></b></td>
									</tr>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
