
	<div class="contentpage">
		<div class="row">	
			<div class="summary">
				<div class="box box1">
					<h4>TOTAL <span>No. Of Students</span></h4>
					<div class="innercont">	
						<span>319</span>
						<i class="fas fa-user-tie"></i>
					</div>	
				</div>
				<div class="box box2">
					<h4>TOTAL <span>No. Of Parents</span></h4>
					<div class="innercont">	
						<span>319</span>
						<i class="fas fa-users-cog"></i>
					</div>	
				</div>
				<div class="box box3">
					<h4>TOTAL <span>No. Of Teachers</span></h4>
					<div class="innercont">	
						<span>13</span>
						<i class="fas fa-male"></i>
					</div>	
				</div>
				<div class="box box4">
					<h4>TOTAL <span>No. Of Active Classes</span></h4>
					<div class="innercont">	
						<span>651</span>
						<i class="fas fa-users"></i>
					</div>	
				</div>
			</div>
			<div class="dashboardWidget">
				<div class="contleft">
					<div class="header">
						<p>	
							<i class="far fa-calendar-alt fnt"></i>
							<span>Event</span>
						</p>
					</div>
					<div class="eventcontent">
						<p>Information comming soon...</p>
					</div>
				</div>
				<div class="contright">
					<div class="innercont2">
						<div class="header">
							<p>	
								<i class="far fa-calendar-alt fnt"></i>
								<span>Announcement</span>
							</p>
						</div>
						<div class="eventcontent">
							<p>ATTENTION TO ALL GRADE 7 STUDENTS, YOU ARE ALL REQUIRED TO ATTEND THE MEETING.</p>
						</div>
					</div>
				</div>
			</div>	
		</div>	
	</div>
