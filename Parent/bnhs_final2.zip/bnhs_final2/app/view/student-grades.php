
<div class="contentpage">
	<div class="row">
		<div id="widget">
			<div class="header">
				<p><i class="fas fa-file fnt"></i><span> Grades</span></p>
			</div>
			<div class="widgetcontent">
				<table>
					<tr>
						<th>Subject</th>
						<th>1st Grading</th>
						<th>2nd Grading</th>
						<th>3rd Grading</th>
						<th>4th Grading</th>
						<th>Final Grade</th>
						<th>Remarks</th>
					</tr>
					<tr>
						<td class="text-bold"><span>English</span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
					</tr>
					<tr>
						<td class="text-bold"><span>Math</span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
					</tr>
					<tr>
						<td class="text-bold"><span>AP</span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
					</tr>
					<tr>
						<td class="text-bold"><span>Science</span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
					</tr>
					<tr>
						<td class="text-bold"><span>TLE</span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
					</tr>
					<tr>
						<td class="text-bold"><span>Filipino</span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
					</tr>
					<tr>
						<td class="text-bold"><span>MAPEH</span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
					</tr>
					<tr>
						<td class="text-bold"><span>Music</span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
					</tr>
					<tr>
						<td class="text-bold"><span>Arts</span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
					</tr>
					<tr>
						<td class="text-bold"><span>PE</span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
					</tr>
					<tr>
						<td class="text-bold"><span>Health</span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
					</tr>
					<tr>
						<td class="text-bold"><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
						<td><span></span></td>
					</tr>
				</table>
			</div>
		</div>
	</div>