
<div class="contentpage">
	<div class="row">
		<div id="widget">
			<div class="header">
				<p><i class="fas fa-check-square fnt"></i><span> Attendance</span></p>
			</div>
			<div class="widgetcontent">
				<table>
					<tr>
						<th>Subject</th>
						<th>Date</th>
						<th>Tardy/Absent</th>
						<th>Status</th>
					</tr>
					<tr>
						<td><span>English</span></td>
						<td><span>Jan 4, 2019</span></td>
						<td><span>Absent</span></td>
						<td><span>Cleared</span></td>
					</tr>
					<tr>
						<td><span>Math</span></td>
						<td><span>Jan 4, 2019</span></td>
						<td><span>Absent</span></td>
						<td><span></span></td>
					</tr>					

				</table>
			</div>
		</div>
	</div>
</div>