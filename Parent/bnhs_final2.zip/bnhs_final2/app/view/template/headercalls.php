	<link rel="icon" href="public/images/favicon.png" type="image/x-icon">

	<link href="<?php echo URL; ?>public/styles/style.css" rel="stylesheet" type="text/css">

	<link href="<?php echo URL; ?>public/libs/sidebar-menu/sidebar-menu.css" rel="stylesheet" type="text/css">

	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/css/cookieconsent.min.css" />

	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/css/all.css" />

	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/css/fullcalendar.css" />

	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/datatables/datatables.css"/>
	
	<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/smoothness/jquery-ui.css">

 

	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/js/jquery-3.3.1.js"></script>

	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/js/jquery-ui.js"></script>

 	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/datatables/datatables.min.js"></script>

	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/js/moment.min.js"></script>

	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/js/fullcalendar.min.js"></script>

	