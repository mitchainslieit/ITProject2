<?php 
require '../connection.php';
require '../other-funct.php';
class FacultyAjax {

	public function __construct() {
		$this->others = new OtherMethods;
		$this->conn = new Connection;
		$this->conn = $this->conn->connect();
	}

	public function setLevel() {
		$year_level = explode('=', $_POST['data'][1]);
		$sql = $this->conn->query("SELECT subj_level FROM subject JOIN section ON subj_level = grade_lvl WHERE sec_id = ".$year_level[1]." GROUP BY grade_lvl");
		$result = $sql->fetch();
		$_SESSION['subj_lvl'] = $result['subj_level'];
	}

	public function setDept() {
		$subj_id = explode('=', $_POST['data'][1]);
		$sql = $this->conn->query("SELECT fac_id, CONCAT(fac_fname, ' ', fac_midname, ' ', fac_lname) 'name' FROM subject JOIN faculty ON subj_dept = fac_dept WHERE subj_id = ".$subj_id[1]);
		$result = $sql->fetchAll();
		$option = '';
		foreach($result as $row) {
			$option .= '<option value="'.$row['fac_id'].'">'.$row['name'].'</option>';
		}
		echo $option;
	}

	public function fillOutForm() {
		$id = explode('=', $_POST['data'][1]);
		$sql = $this->conn->query("SELECT * FROM student st JOIN guardian gr ON st.guar_id = gr.guar_id WHERE st.guar_id = '".$id[1]."' GROUP BY st.guar_id LIMIT 1");
		$_SESSION['full_stud_guar_info'] = $sql->fetchAll();
	}

	public function acceptStudent() {
		$sql = $this->conn->query("SELECT sec_id FROM section WHERE sec_id <> (SELECT secc_id FROM student JOIN section ON secc_id = sec_id WHERE stud_id = '".$_POST['data'][1]."') AND grade_lvl = (SELECT year_level FROM student JOIN section ON secc_id = sec_id WHERE stud_id = '".$_POST['data'][1]."')");
		$result = $sql->fetch();
		$updateSec = $this->conn->query("UPDATE student SET secc_id = '".$result['sec_id']."', sec_stat='Permanent' WHERE stud_id = '".$_POST['data'][1]."'") or die("Query failed!");
		echo "<div data-type='message' style='position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); z-index: 9999999; overflow: hidden;'>
			<div style='width:100%; padding: 17px 0; background: rgb(0, 244, 0); color: #fff;'>
					<div class='modal-box' style='width: 100%;'>
						<p style='margin: 0; font-size: 16px;'>The student has successfully been transferred to your section, Wait <span class='count'>5</span> seconds or <a style='color: #4b4bff; text-decoration: underline;' href='faculty-student'>Click here</a></p>
					</div>
				</div>
			</div>
			<script>
			$('div[data-type=message]').appendTo('body');
			$('div[id*=\"_home\"]').addClass('modal-enabled');
			var sec = 4;
			var timer = setInterval(function() {
				$('.modal-box .count').text(sec--);
				if (sec == -1) {
					clearInterval(timer);
				}
			}, 1000);
			setTimeout(function(){
			   window.location = 'faculty-student';
			}, 4000);
			</script>";
	}

	public function rejectStudent() {
		$sql = $this->conn->query("UPDATE student SET sec_stat='Permanent' WHERE stud_id ='".$_POST['data'][1]."'");
		echo "<div data-type='message' style='position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); z-index: 9999999; overflow: hidden;'>
			<div style='width:100%; padding: 17px 0; background: rgb(244, 0, 0); color: #fff;'>
					<div class='modal-box' style='width: 100%;'>
						<p style='margin: 0; font-size: 16px;'>The student was not transferred, Wait <span class='count'>5</span> seconds or <a style='color: #4b4bff; text-decoration: underline;' href='faculty-student'>Click here</a></p>
					</div>
				</div>
			</div>
			<script>
			$('div[data-type=message]').appendTo('body');
			$('div[id*=\"_home\"]').addClass('modal-enabled');
			var sec = 4;
			var timer = setInterval(function() {
				$('.modal-box .count').text(sec--);
				if (sec == -1) {
					clearInterval(timer);
				}
			}, 1000);
			setTimeout(function(){
			   window.location = 'faculty-student';
			}, 4000);
			</script>";
	}

	public function transferStudent() {
		$sql = $this->conn->query("UPDATE student SET sec_stat='Temporary' WHERE stud_id ='".$_POST['data'][1]."'") or die('Query Failed!');
		echo "<div data-type='message' style='position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); z-index: 9999999; overflow: hidden;'>
			<div style='width:100%; padding: 17px 0; background: rgb(0, 244, 0); color: #fff;'>
					<div class='modal-box' style='width: 100%;'>
						<p style='margin: 0; font-size: 16px;'>You have requested to tranfer the student, Wait <span class='count'>5</span> seconds or <a style='color: #4b4bff; text-decoration: underline;' href='faculty-student'>Click here</a></p>
					</div>
				</div>
			</div>
			<script>
			$('div[data-type=message]').appendTo('body');
			$('div[id*=\"_home\"]').addClass('modal-enabled');
			var sec = 4;
			var timer = setInterval(function() {
				$('.modal-box .count').text(sec--);
				if (sec == -1) {
					clearInterval(timer);
				}
			}, 1000);
			setTimeout(function(){
			   window.location = 'faculty-student';
			}, 4000);
			</script>";
	}

	public function cancelTransferStudent() {
		$sql = $this->conn->query("UPDATE student SET sec_stat='Permanent' WHERE stud_id ='".$_POST['data'][1]."'");
		echo "<div data-type='message' style='position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); z-index: 9999999; overflow: hidden;'>
			<div style='width:100%; padding: 17px 0; background: rgb(244, 0, 0); color: #fff;'>
					<div class='modal-box' style='width: 100%;'>
						<p style='margin: 0; font-size: 16px;'>The request has been cancelled, Wait <span class='count'>5</span> seconds or <a style='color: #4b4bff; text-decoration: underline;' href='faculty-student'>Click here</a></p>
					</div>
				</div>
			</div>
			<script>
			$('div[data-type=message]').appendTo('body');
			$('div[id*=\"_home\"]').addClass('modal-enabled');
			var sec = 4;
			var timer = setInterval(function() {
				$('.modal-box .count').text(sec--);
				if (sec == -1) {
					clearInterval(timer);
				}
			}, 1000);
			setTimeout(function(){
			   window.location = 'faculty-student';
			}, 4000);
			</script>";
	}

	public function getNotif(){
		$sql = $this->conn->prepare("SELECT *, CONCAT(first_name, ' ', middle_name, ' ', last_name) as stud_fullname FROM accounts JOIN faculty ON acc_id = acc_idz JOIN section ON fac_id = fac_idv JOIN student ON sec_id = secc_id WHERE sec_stat = 'Temporary' AND grade_lvl = (SELECT grade_lvl FROM accounts JOIN faculty ON acc_id = acc_idz JOIN section ON fac_id = fac_idv WHERE acc_id = :acc_id) AND acc_id <> :acc_id");
		$sql->execute(array(':acc_id' => $_SESSION['accid']));
		$_SESSION['notif'] = $sql->rowCount();
		$data = array();
		$data['response'] = $_SESSION['notif'];
		echo json_encode($data);
	}
}

/* OUTSIDE THE CLASS */
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
$run = new FacultyAjax;
if(isset($_POST['data'][0]) && $_POST['data'][0] === 'setLevel') $run->setLevel();
if(isset($_POST['data'][0]) && $_POST['data'][0] === 'setSubj') $run->setDept();
if(isset($_POST['data'][0]) && $_POST['data'][0] === 'filloutform') $run->fillOutForm();
if(isset($_POST['data'][0]) && $_POST['data'][0] === 'accept') $run->acceptStudent();
if(isset($_POST['data'][0]) && $_POST['data'][0] === 'reject') $run->rejectStudent();
if(isset($_POST['data'][0]) && $_POST['data'][0] === 'transfer') $run->transferStudent();
if(isset($_POST['data'][0]) && $_POST['data'][0] === 'cancel') $run->cancelTransferStudent();
if(isset($_GET['data'][0]) && $_GET['data'][0] === 'getNotif') $run->getNotif();
?>