<div id="content">
	<div class="row">
		<h1>Privacy Policy</h1>
		<div class="inPrivacyBox">
			<p>
				Lorem ipsum dolor sit amet, pri eu delenit honestatis, iusto accusamus his in. Nisl viris minimum sed ne. Ei qui quas justo, cu dicam denique his, diam percipit ei est. His no meis vituperatoribus, eam no sale velit facilisis. Te his tale constituto, vel cu porro omittantur. In mei graeco dolorum inermis. Sea sapientem mnesarchum deterruisset ei, eu iracundia euripidis eos, vel dolorem gloriatur at.
			</p>
			<p>
				Eu cum oratio denique pertinacia, deseruisse accommodare id eum. Erant vulputate usu ne. Ei vel putant mandamus, mea ex sensibus inimicus posidonium. Vivendum verterem no sit, an veritus adolescens dissentiet vim, nec ex officiis incorrupte neglegentur. Usu ex esse animal signiferumque.
			</p>
			<p>
				Ad dicam mediocrem has, eius integre sadipscing sea ex. Mei in atqui dolor. Accumsan deseruisse ad nec, vis ea veniam labores, patrioque deterruisset an ius. Ei augue partem praesent vim, nam tritani mandamus reformidans et, putent molestiae dissentiunt eu nam. Usu ut omittam detracto repudiandae.
			</p>
			<p>
				Vis eu laudem partiendo, ea duo iisque accusata, homero maluisset nec id. Has id decore veritus eloquentiam, in cum nominavi ponderum. An prompta delectus oportere mel, illud fugit ex sed, liber definitiones has cu. Qui in movet graece numquam.
			</p>
			<p>
				Quot numquam sea an. Sit ad sumo debet. Ea augue populo pro, nobis dolor et ius. Ignota mucius euripidis at ius. Qui verear propriae dissentias et.
			</p>
		</div>
	</div>
</div>


