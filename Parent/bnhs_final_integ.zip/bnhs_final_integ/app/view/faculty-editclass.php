<?php require 'app/model/faculty-funct.php'; $getFactFunct = new FacultyFunct() ?>
<?php
	if(isset($_POST['submit-classes'])) {
		$getFactFunct->setSchedule($_POST);
	}
?>
<div class="contentpage">
	<div class="row">	
		<div class="widget">	
			<div class="header">	
				<p>	<i class="fas fa-user-plus fnt"></i><span> Edit Class</span></p>
				<div class="select-filter">
					<span>Grade Level & Section: </span>
					<select name="sec_id" id="getCurrentLevel">
						<?php $getFactFunct->showSections(); ?>
					</select>
				</div>
				<p>School Year: 2019-2020</p>
			</div>	
			<div class="editContent widgetcontent">
				<div class="cont3">
					<div class="table-scroll">	
						<?php $getFactFunct->showTabledSections(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>