
    <div class="contentpage">
        <div class="row">
            <div class="summary">
                <div class=""></div>
            </div>
        </div>
    </div>
 <!-- 
<div class="soawidget">
                <div class="header">
                    <p>
                        <i class="fas fa-money-bill fnt"></i>
                        <span>Statement of Accounts</span>
                    </p>
                </div>
                <div class="widgetcontent">
                    <p>Amount to pay: <span>&nbsp;Php 1,000</span></p>
                    <h3>History of Payment</h3>
                    <table>
                        <tr>
                            <th>Date</th>
                            <th>Amount</th>
                        </tr>
                        <tr>
                            <td><span>July 3, 2018</span></td>
                            <td><span>3,000</span></td>
                        </tr>
                    </table>
                </div>
                <div class="widget">
                    <div class="header">
                        <p><i class="fas fa-file fnt"></i><span> Breakdown</span></p>
                    </div>
                    <div class="widgetcontent">
                        <table>
                        <tr>
                            <th>Description</th>
                            <th>Amount</th>
                        </tr>
                        <tr>
                            <td>PTA</td>
                            <td>Php 300</td>
                        </tr>
                        <tr>
                            <td>Utility</td>
                            <td>Php 300</td>
                        </tr>
                        <tr>
                            <td>School Paper</td>
                            <td>Php 150</td>
                        </tr>
                        <tr>
                            <td>Organization Fee</td>
                            <td>Php 150</td>
                        </tr>
                        <tr>
                            <td>Technology Livelihood Education Fee</td>
                            <td>Php 75</td>
                        </tr>
                        <tr>
                            <td>Science Fee</td>
                            <td>Php 50</td>
                        </tr>
                        <tr>
                            <td>Supreme Student Government (SSG)</td>
                            <td>Php 75</td>
                        </tr>
                        <tr>
                            <td>Internet for students</td>
                            <td>Php 250</td>
                        </tr>
                        <tr>
                            <td class="text-bold">Total</td>
                            <td class="text-bold">Php 1350</td>
                        </tr>
                    </table>
                    </div>

                </div>
            </div>
 -->