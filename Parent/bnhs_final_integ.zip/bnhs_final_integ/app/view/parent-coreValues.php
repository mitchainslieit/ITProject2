<?php require 'app/model/parent_funct.php'; $run= new ParentFunct ?>
    <div class="contentpage">
        <div class="row">
            <div class="widget">
                <div class="header">
                    <p>
                        <i class="fas fa-book-open fnt"></i>
                        <span>Child Core Value</span>
                    </p>
                    <p>School Year:
                        <?php $run->getSchoolYear(); ?>
                    </p>
                </div>
                <div class="eventcontent">
                    <div class="sample">
                        <div class="tl"><b>Child Name:</b>
                            <select name="student" class="student" id="select-child-grade">
                                <?php 
                            foreach($run->getNameOfStud() as $row) {
                                extract($row);
                                echo '
                                <option value="'.$stud_lrno.'" name="stud_name"> '.$name.' - '.$section.'  </option>
                                ';
                            }
                            ?>
                            </select>
                        </div>
                    </div>
                    <br>
                    <div class="cont3">
                        <div class="table-scroll">
                            <div class="table-wrap" id="table-grade-student">
                                <table id="grade-student">
                                    <?php $lrno = !isset($_SESSION['child_lrno']) ? $run->getLRNOfStud() : $_SESSION['child_lrno']; ?>
                                        <tr>
                                            <th>GRADING</th>
                                            <th>MAKADIYOS</th>
                                            <th>MAKATAO</th>
                                            <th>MAKAKALIKASAN</th>
                                            <th>MAKABANSA</th>
                                        </tr>
                                           <?php $run->getChildCoreValues1st($lrno); ?>
                                           <?php $run->getChildCoreValues2nd($lrno); ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <p style="text-align:left; color:blue;font-weight: 600; font-size: 18px">LEGEND FOR CORE VALUES</p>
            <div class="cont4">
                <table>
                    <tr>
                        <th colspan="2">Non-numerical Rating</th>
                        <th>Marking</th>
                    </tr>
                    <tr>
                        <td>Always Observed</td>
                        <td colspan="2"><font color="green"><b>AO</font></b></td>
                    </tr>
                        <td>Sometimes Observed</td>
                        <td colspan="2"><font color="blue"><b>SO</font></b></td>
	                </tr>
                    <tr>
                        <td>Rarely Observed</td>
                        <td colspan="2"><font color="orange"><b>RO</font></b></td>
                    </tr>
                    <tr>
                        <td>Not Observed</td>
                        <td colspan="2"><font color="red"><b>NO</font></b></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
    <?php if (isset($_SESSION['child_lrno'])) unset($_SESSION['child_lrno']); ?>