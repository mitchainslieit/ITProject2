
<div class="contentpage">
	<div class="row">
		<div class="container">
			<div class="cont cont1">
				<img src="public/images/common/profile.png"> </br>
				<p><span>Chris S. Yang</span></p>
				<button class="btn">Change Password</button>
			</div>
			<div class="cont cont2">
				<div id="widget">
				<div class="header">
					<p><i class="fas fa-user fnt"></i><span>Student Information</span></p>
				</div>
				<div class="widgetcontent">
					<div class="conthead">
						<p>General Information</p>
					</div>
					<div class="continue">
							<form>
								<label for="sexfield"><span>Sex:</span><input type="text" name="" value="Male" disabled></label>
								<label for="birthday"><span>Birthday:</span><input type="text" name="" value="July 16" disabled></label>
								<label for="religion"><span>Religion:</span><input type="text" name="" value="Catholic" disabled></label>
								<label for="nationality"><span>Nationality:</span><input type="text" name="" value="Filipino" disabled></label>
							</form>
					</div>
					<div class="conthead">
						<p>Contact Information</p>
					</div>
					<div class="continue">
							<form>
								<label for="address"><span>Address:</span><input type="text" name="" value="Bakakeng Baguio" disabled></label>
								<label for="fname"><span>Father's Name:</span><input type="text" name="" value="John Doe" disabled></label>
								<label for="mname"><span>Mother's Name:</span><input type="text" name="" value="Jane Doe" disabled></label>
								<label for="guardian"><span>Guardian:</span><input type="text" name="" value="Ewan ko" disabled></label>
								<label for="telno"><span>Telephone Number:</span><input type="text" name="" value="445-423-22" disabled></label>
								<label for="cpno"><span>Cellphone Number:</span><input type="text" name="" value="0922-222-2222" disabled></label>
							</form>
					</div>
				</div>
			</div>
			</div>
		</div>
	</div>
</div>

<!--<div class="imageholder">
			<img src="public/images/common/profile.png">	
			<div id="widget">
				<div class="header">
					<p><i class="fas fa-user fnt"></i><span>Student Information</span></p>
				</div>
				<div class="widgetcontent">
					<p> asdasdasdasd</p>
				</div>
			</div>	
		</div>
		<div class="imagedetails">
				<p><span>John Doe</span></p>
		</div> -->