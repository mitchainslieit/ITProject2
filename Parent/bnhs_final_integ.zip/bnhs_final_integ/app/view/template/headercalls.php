	<link rel="icon" href="public/images/favicon.png" type="image/x-icon">
	<link href="<?php echo URL; ?>public/styles/style.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/css/cookieconsent.min.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/css/all.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/css/fullcalendar.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/datatables/datatables.min.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/jquery-ui/jquery-ui.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/ambiance/jquery.ambiance.css"/>

	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/js/jquery-3.3.1.js"></script>
	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/jquery-ui/jquery-ui.js"></script>
 	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/datatables/datatables.min.js"></script>
	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/js/moment.min.js"></script>
	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/js/fullcalendar.min.js"></script>
	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/js/jquery.form-validator.min.js"></script>
	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/printThis/printThis.js"></script>
	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/ambiance/jquery.ambiance.js"></script>