/** 
 * SITE FUNCTIONALITIES
 *
 * IT CONTAINS THE USAGE OF API'S AND 
 */

replacePageTitle();
/****************************************** START OF FRONT-END FUNCTIONALITIES USING JQUERY (CALLED WITHOUT WAITING FOR THE PAGE TO FULLY LOAD) ******************************************/
/*Dropdown menu, specifically for the profile dropdown*/
$( ".dropdown-menu .dropdown-btn" ).click(function(e) {
	e.stopPropagation();
	$(".dropdown-menu-content").fadeToggle();
});

$( "html" ).click(function(e) {
	e.stopPropagation();
	var container = $(".dropdown-menu-content");

	//check if the clicked area is dropDown or not
	if (container.has(e.target).length === 0) {
		$('.dropdown-menu-content').fadeOut();
	}
});

/*Custom Sidebar using pure jQuery*/
$('.menu-sidebar .menu nav ul li a[href^=" "]').click(function(event) {
	event.preventDefault();
	var oldSubMenu = "#" + $('.menu-sidebar .menu nav ul li ul.active-submenu').attr('id');
	var submenuID = "#" + $(this).attr("target");
	if (!($('.menu-sidebar .menu nav ul li').hasClass('active')) || $(submenuID).parent('li').hasClass('active')) {
		$(submenuID).parent('li').toggleClass('active');
		$(submenuID).slideToggle();
	} else {
		$('.menu-sidebar .menu nav ul li.active ul').slideUp();
		$('.menu-sidebar .menu nav ul li.active').removeClass('active');
		$(submenuID).parent('li').addClass('active');
		$(submenuID).slideDown();
	}
});

if ($('.menu-sidebar .menu nav ul li ul li').hasClass('active-menu')) {
	$('.menu-sidebar .menu nav ul li').has('li.active-menu').addClass('active');
	$('.menu-sidebar .menu nav ul li.active ul').show();
}

var ifColAct = localStorage.getItem('collapse-menu');

$('#collapse-menu').click(function() {
	$('div.menu-top').toggleClass('top-compress');
	$('div.menu-sidebar').toggleClass('sidebar-compress');
	$('div.content-container').toggleClass('content-compress');
	$('.menu-sidebar .menu nav ul li#advisory span.notification').toggle();
	ifColAct === null ? localStorage.setItem('collapse-menu', 'active') : localStorage.removeItem('collapse-menu');
});

if (ifColAct === 'active') {
	$('div.menu-top').addClass('top-compress');
	$('div.menu-sidebar').addClass('sidebar-compress');
	$('div.content-container').addClass('content-compress');
	$('.menu-sidebar .menu nav ul li#advisory span.notification').hide();
}

$('.menu nav > ul > li').each(function() {
	var newDiv = '<span class="menu-title">' + $(this).children('a').text() + '</span>';
	$(this).children('a').append(newDiv);
});

$('.sidebar-submenu li').each(function() {
	var newDiv = '<span class="menu-title">' + $(this).children('a').text() + '</span>';
	$(this).children('a').append(newDiv);
});

$( ".datepicker" ).datepicker({
	changeMonth: true,
	changeYear: true,
	yearRange: "-25:+0",
	dateFormat: 'yy-mm-dd'
});

$('[name=opener]').each(function () {
  var panel = $(this).siblings('[name=dialog]');
  $(this).click(function () {
      panel.dialog('open');
      $('.ui-widget-overlay').addClass('custom-overlay');
  });
});
$('[name=dialog]').dialog({
	autoOpen: false,
	modal: true,
	draggable: false,
	height: 'auto',
	width: 'auto'
});

$('#existing-guardian-autofill-submit').on('click', function() {
	var data = new Array('filloutform', 'guar_id=' + $(this).siblings('#existing-guardian-autofill').val());

	$.ajax({
		type: 'POST',
		url: 'app/model/faculty-exts/faculty-ajax.php',
		data: {data:data},
		success: function(result) {
			$('[name=dialog]').dialog('close');
			$('#auto-fill').load('faculty-enroll #auto-fill .form-row');
		}
	});
});

$('#faculty_home .contentpage .widget .studentContent #adv-table-1 tr td').on('click', 'button.transfer', function() {
	var data = new Array('transfer', $(this).siblings('.stud_id').val());

	$.ajax({
		context: this,
		type: 'POST',
		url: 'app/model/faculty-exts/faculty-ajax.php',
		data: {data:data},
		success: function(result) {
			$(this).append(result);
		}
	});
});

$('#faculty_home .contentpage .widget .studentContent #adv-table-1 tr td').on('click', 'button.transfer', function() {
	var data = new Array('transfer', $(this).siblings('.stud_id').val());

	$.ajax({
		context: this,
		type: 'POST',
		url: 'app/model/faculty-exts/faculty-ajax.php',
		data: {data:data},
		success: function(result) {
			$(this).append(result);
		}
	});
});

$('#faculty_home .contentpage .widget .studentContent .details').on('click', 'button.cancel', function() {
	var data = new Array('cancel', $(this).siblings('.stud_id').val());

	$.ajax({
		context: this,
		type: 'POST',
		url: 'app/model/faculty-exts/faculty-ajax.php',
		data: {data:data},
		success: function(result) {
			$(this).append(result);
		}
	});
});

$('#faculty_home .contentpage .widget .studentContent .details').on('click', 'button.accept', function() {
	var data = new Array('accept', $(this).siblings('.stud_id').val());

	$.ajax({
		context: this,
		type: 'POST',
		url: 'app/model/faculty-exts/faculty-ajax.php',
		data: {data:data},
		success: function(result) {
			$(this).append(result);
		}
	});
});

$('#faculty_home .contentpage .widget .studentContent .details').on('click', 'button.reject', function() {
	var data = new Array('reject', $(this).siblings('.stud_id').val());

	$.ajax({
		context: this,
		type: 'POST',
		url: 'app/model/faculty-exts/faculty-ajax.php',
		data: {data:data},
		success: function(result) {
			$(this).append(result);
		}
	});
});

$('.parent-account-page #select-children').on('change', function() {
	var data = 'lrno=' + $(this).val();

	$.ajax({
		type: 'POST',
		url: 'app/model/unstructured/parent-changeSession.php',
		data: data,
		success: function(result) {
			$('#children-totals').load('parent-account #children-totals .container');
		}
	});
});

$('.parent-attendance-page #select-children').on('change', function() {
	var data = 'lrno=' + $(this).val();

	$.ajax({
		type: 'POST',
		url: 'app/model/unstructured/parent-changeSession.php',
		data: data,
		success: function(result) {
			$('.parent-attendance-page #attendance-container').load('parent-attendance #attendance-container-load');
		}
	});
});

$('.parent-grades-page #select-child-grade').on('change', function() {
	var data = 'lrno=' + $(this).val();

	$.ajax({
		type: 'POST',
		url: 'app/model/unstructured/parent-changeSession.php',
		data: data,
		success: function(result) {
			$('#table-grade-student').load('parent-grades  #grade-student');
		}
	});
});

$('.parent-schedule-page #select-child-schedule').on('change', function() {
	var data = 'lrno=' + $(this).val();

	$.ajax({
		type: 'POST',
		url: 'app/model/unstructured/parent-changeSession.php',
		data: data,
		success: function(result) {
			$('#table-children-schedule').load('parent-schedule #table-children-schedule table');
		}
	});
});

/*Add page title using the active-menu*/
function replacePageTitle() {
	$('title').empty();
	$('title').append($( '.menu nav ul li.active-menu a' ).text());
}

getCurrentSection('sec1');

$('.faculty-editclass-page #getCurrentLevel').on('change', function() {
	var val = $(this).val();
	getCurrentSection(val);
});

function getCurrentSection(value) {
	var showThis = '.faculty-editclass-page .table-scroll #'+value;
	var hideThis = '.faculty-editclass-page .table-scroll .classes-edit:not(#'+value+')';
	$(hideThis).each(function() {
		$(this).hide();
	});
	$(showThis).show();
}

/****************************************** END OF FRONT-END FUNCTIONALITIES USING JQUERY (CALLED WITHOUT WAITING FOR THE PAGE TO FULLY LOAD) ******************************************/

/****************************************** START OF FRONT-END FUNCTIONALITIES USING JQUERY ******************************************/
$( document ).ready(function() {
	$( ".se-pre-con" ).fadeOut("slow");

	/****************************************** START OF API(s) ******************************************/
	/*Jquery UI Tabs*/
	$( ".tabs" ).tabs();
	$( ".enrollcontent .tabs" ).tabs({ active: 1 });
	$( ".studentContent .tabs, .classesContent .tabs" ).tabs();

	/*Datatable API*/
	var datatable = $( "#stud-list, #adv-table-1" ).DataTable({
		dom: "lfrtip",
		"lengthMenu": [[5, 10, 25, -1], [5, 10, 25, 'All']]
	});

	var customContent = $( "#customParentTable" ).DataTable({
		dom: "lfrtip",
		"lengthMenu": [[5, 10, 25, -1], [5, 10, 25, 'All']]
	});

	var studlist = $('#old-student').DataTable({
		"columnDefs" : [{
			"targets": [4],
			"visible": false,
		}]
	});

	studlist.column(2).search( 'Not Enrolled' ).draw();

	$('.faculty-enroll-page #filter-stud-list').on('change', function() {
		var val = $(this).val();
		studlist.column(4).search( val ? val : '', true, false ).draw();
	});

	$('.faculty-enroll-page #filter-stud-list-transfers').on('change', function() {
		var val = $(this).val();
		if (val == 'Yes') {
			studlist.column(2).search( '' ).draw();
		} else {
			studlist.column(2).search( 'Not Enrolled' ).draw();
		}
	});

	/*$('#add-new-row').on('click', function() {
		studlist.row.add([
		    '1234567890123', 'Mitch Ainslie Galatcha', 'Not Enrolled', '<button id="ABCDEFGHIJK">Sample</button>', '8'
		]).draw();
	});

	$('#faculty_home .contentpage .widget .widgetcontent table#old-student').on('click', '#ABCDEFGHIJK', function() {
		alert('working');
	});*/

	/*FullCalendar API*/
	var calendar = $('#calendar').fullCalendar({
		header:{
			left:'prev,next today',
			center:'title',
			right:'month,agendaWeek,agendaDay'
		},
		events: 'app/model/unstructured/load.php',
		selectHelper:true,
		height: 500
	});

	var faculty_calendar = $('#calendar-faculty').fullCalendar({
		header:{
			left:'prev,next today',
			center:'title',
			right:'month,agendaWeek,agendaDay'
		},
		events: 'app/model/unstructured/load.php',
		selectHelper:true,
		height: 300
	});

	/*jQuery Form Validator API*/
	$.validate();

	/****************************************** END OF API(s) ******************************************/

	$('.faculty-assess-page').on('click', '#print-this', function() {
		$('.faculty-assess-page .print-container').printThis({
			importCSS: true,
			importStyle: true,
		});
	});

	$('.faculty-editclass-page #faculty_home .cont').on('change', 'select#getCurrentLevel', function() {
		var data = new Array('setLevel', 'subj_lvl=' + $(this).val());

		$.ajax({
			type: 'POST',
			url: 'app/model/faculty-exts/faculty-ajax.php',
			data: {data:data},
			success: function(result) {
				$('#classes-sched').load('faculty-editclass #classes-sched');
			}
		});
	});

	$('#classes-sched').on('change', 'select.editclass-subjects', function() {
		var data = new Array('setSubj', 'subj_id=' + $(this).val());
		if ($(this).val() == '') {
			$(this).siblings('.editclass-teacher').empty();
			$(this).siblings('.editclass-teacher').append('<option value="" disabled selected>Select a subject first to display data</option>');
		} else {
			$.ajax({
				context: this,
				type: 'POST',
				url: 'app/model/faculty-exts/faculty-ajax.php',
				data: {data:data},
				success: function(result) {
					$(this).siblings('.editclass-teacher').empty();
					$(this).siblings('.editclass-teacher').append(result);
				}
			});
		}
		
	});

	var selects = function() {
		var array = [];
		$('#editClass-form select.editclass-subjects').each(function() {
			array.push($(this).val());
		});
		return jQuery.unique( array ).length == 7 ? true : false;
	}

	$('#editClass-form').on('click', 'button', function(e) {
		e.preventDefault();
		var exists = false;
		$('#editClass-form select.editclass-subjects').each(function(){
			if($(this).val() == '') {
				exists = true;
			}
		});
		if (exists == false && selects() == true) {
			$('#editClass-form').submit();
		} else {
			alert('Please choose a subject for each schedule or a subject has been choosen twice.');
		}
	});
});

var forTransferTable = $('#adv-table-2').DataTable();

setInterval(function() {
	var data = new Array('getNotif', parseInt($('body[class*="faculty-"] .menu-sidebar .menu nav ul li#advisory span.notification').text()));

	$.ajax({
		type: 'get',
		url: 'app/model/faculty-exts/faculty-ajax.php',
		data: {data:data},
		success: function(result) {
			var data = JSON.parse(result);
			var current_no = parseInt($('body[class*="faculty-"] .menu-sidebar .menu nav ul li#advisory span.notification').text());
			var new_no = data["response"];
			if ((current_no != new_no) && $('body').is('[class*="faculty-"]')) {
				$('body[class*="faculty-"] .menu-sidebar .menu nav ul li#advisory span.notification, #faculty_home .contentpage .widget .studentContent .notification').empty();
				$('body[class*="faculty-"] .menu-sidebar .menu nav ul li#advisory span.notification, #faculty_home .contentpage .widget .studentContent .notification').append(new_no);
				$.ambiance({
					message: "A Sample Notification",
		            type: "success"
		        });
			}
		}
	});
}, 3000);
/****************************************** END OF FRONT-END FUNCTIONALITIES USING JQUERY ******************************************/
