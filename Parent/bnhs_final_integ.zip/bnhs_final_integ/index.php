<?php
	require "config/config.php";
	$app = new App();
?>