<?php require 'app/model/parent_funct.php'; $run= new ParentFunct ?>
	<div class="contentpage">
		<div class="row">	
			<div class="dashboardWidget">
				<div class="cont2">	
					<div class="header">
						<p>	
							<i class="far fa-calendar-alt fnt"></i>
							<span>Calendar</span>
						</p>
					</div>
					<div class="eventcontent">
						<div id="calendar" style="padding: 15px;"></div>
					</div>
				</div>
			</div>
		</div>	
	</div>