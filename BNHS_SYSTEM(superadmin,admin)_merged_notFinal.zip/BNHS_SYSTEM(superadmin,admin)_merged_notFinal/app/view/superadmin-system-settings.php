<?php require 'app/model/Superadmin-funct.php'; $obj = new SAdminFunct;?>
<?php
if(isset($_POST['insert-holiday-button'])){
	extract($_POST);
	$obj->insertHolidays();
}
if(isset($_POST['start-button'])){
	extract($_POST);
	$obj->schoolYear($sy_start, $sy_end);
}
if(isset($_POST['sy-button'])){
	extract($_POST);
	$obj->syStatus($sy_status);
}
if(isset($_POST['edit-class-button'])){
	extract($_POST);
	$obj->editClass($edit_class);
}
if(isset($_POST['enable-grading-button'])){
	extract($_POST);
	$obj->activeGrading($active_grading);
}
if(isset($_POST['select-grading-period'])){
	extract($_POST);
	$obj->selectGradingPeriod($active_grading);
}
if(isset($_POST['transfer-button'])){
	extract($_POST);
	$obj->transferStudents($student_transfer);
}
if(isset($_POST['select-grading-curriculum'])) {
	$obj->selectGradingPeriod($_POST);
}
?>
<div class="contentpage">
	<div class="row">
		<div class="widget">
			<div class="header">
				<div class="cont">
					<i class="fas fa-cog"></i>
					<span>System Settings</span>
				</div>
				<p>School Year: <?php $obj->getSchoolYear(); ?></p>
			</div>
			<div class="widgetContent systemContent" id="system-settings-div">
				<div class="cont1">
					<div id="accordion-container"> 
						<div class="generalSettings">
							<h2 class="accordion-header"><i class="fas fa-cog fnt2"></i>General Settings</h2> 
							<div class="accordion-content"> 
								<div class="systemContainer schoolYear">
									<div class="systemBox1">
										<div class="innerHeader">
											<span style="font-weight: 500 !important;">School Year:</span>
										</div>
										<?php 
											echo '
												<input type="text" name="sy_start" readonly="readonly" data-validation="required" class="datepicker-schoolyear" data-validation="required" value="'.$sy_start.'" placeholder="Date Start" required>
												<span style="font-weight: 500 !important;">to</span>
												<input type="text" name="sy_end" readonly="readonly" data-validation="required" class="datepicker-schoolyear" value="'.$sy_end.'" data-validation="required" placeholder="End Date" required>
											';
										?>
									</div>
									<p class="tright">
										<button name="start-button" class="customButton">Save <i class="fas fa-save fnt"></i></button>
									</p>
								</div>
								<div class="systemContainer systemCurriculum">
									<div class="systemBox1">
										<div class="innerHeader">
											<span style="font-weight: 500 !important;">Curriculum:</span>
										</div>
										<select name="" id="">
											<option value="">Select Curriculum</option>
										</select>
									</div>
									<p class="tright">
										<button name="start-button" class="customButton">Save <i class="fas fa-save fnt"></i></button>
									</p>
								</div>
								<div class="systemContainer systemCurriculum">
									<div class="systemBox1">
										<div class="innerHeader">
											<span style="font-weight: 500 !important;">Set Grading Period:</span>
										</div>
										<select name="" id="">
											<option value="">1st</option>
										</select>
									</div>
									<p class="tright">
										<button name="start-button" class="customButton">Save <i class="fas fa-save fnt"></i></button>
									</p>
								</div>
								<div class="systemContainer systemHoliday">
									<div class="systemBox1">
										<div class="innerHeader">
											<span style="font-weight: 500 !important;">Set Grading Period:</span>
										</div>
										<p class="tleft">
											<button name="start-button" class="customButton holidayButton">Insert Holidays <i class="fas fa-plus-square fnt"></i></button>
										</p>
									</div>
								</div>
							</div> 
						</div>
						<div class="facultSettings">
							<h2 class="accordion-header"><i class="fas fa-user-cog fnt2"></i>Faculty Settings</h2> 
							<div class="accordion-content"> 
								<p>Section 2 Content</p> 
							</div> 
						</div>
					</div>
				</div>
				<div class="cont2">
				</div>
			</div>
		</div>
	</div>
</div>