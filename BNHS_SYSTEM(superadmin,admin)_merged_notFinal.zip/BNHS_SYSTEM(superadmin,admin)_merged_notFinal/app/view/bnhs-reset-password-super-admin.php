<!DOCTYPE html>
<html>
	<head>
		<title>Reset Admin Account</title>
	</head>
	<body>
		
	</body>
</html>