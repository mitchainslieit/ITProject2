	<div class="contentpage">
        <div class="row">	
            <div class="widget">	
				<div class="header">	
					<p>	
						<i class="fas fa-book-open fnt"></i>
						<span>Attendance Report</span>
					</p>
					<p>School Year: 2019-2020</p>
				</div>	
				<div class="eventcontent">
					<div class="cont1">
					</div>
				</div>
			</div>
	</div>
</div>