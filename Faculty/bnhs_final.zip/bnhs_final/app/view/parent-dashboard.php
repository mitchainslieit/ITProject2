	<div class="contentpage">
		<div class="row">	
			<div class="eventwidget">
				<div class="container contleft">
					<div class="header">
						<p>	
							<i class="far fa-calendar-alt fnt"></i>
							<span>Statement of Account</span>
						</p>
					</div>
				<div class="eventcontent">
                    <div class="cont1">
                        <p><font color="blue" size="5">Balance: Php 1,399.00</font></p>
                    </div>
					<div class="cont3">
						<div class="table-scroll">	
							<div class="table-wrap">	
								<table>
									<tr>
										<th>DATE</th>
										<th>AMOUNT</th>   
									</tr>
									<tr>
										<td>September 12, 2019</td>
										<td>Php 120.00</td>
									</tr>
									<tr>
										<td>September 12, 2019</td>
										<td>Php 120.00</td>
									</tr>
									<tr>
										<td>September 12, 2019</td>
										<td>Php 120.00</td>
                                    </tr>
									<tr>
										<td>September 12, 2019</td>
										<td>Php 120.00</td>
									</tr>
                                    <tr>
										<td><b>TOTAL AMOUNT:</b></td>
										<td><b><font color="green">PHP 1,399.00</font></b></td>
									</tr>
								</table>
							</div>
						</div>
					</div>
                    <div class="cont4">
						<p>Showing 1 to 5 of 250 entries</p>
						<div class="pagination">
							<button class="btn previous">Previous</button>
							<button class="btn active">1</button>
							<button class="btn ">2</button>
							<button class="btn ">3</button>
							<button class="btn ">4</button>
							<button class="btn ">5</button>
							<button class="btn next">Next</button>
					    </div>
				    </div>
				</div>
				</div>
				<div class="container contright">
					<div class="innercont1">
						<div class="header">
							<p>	
								<i class="far fa-calendar-alt fnt"></i>
								<span>Breakdown of Fees</span>
							</p>
						</div>
						<div class="eventcontent">
							<div class="table-scroll">	
							<div class="table-wrap">	
								<table>
									<tr>
										<th>DATE</th>
										<th>EVENT</th>   
									</tr>
									<tr>
										<td>January 01 & 02, 2019</td>
										<td>Holiday: New Year's Day</td>
									</tr>
									<tr>
										<td>January 03, 2019</td>
										<td>Balik Eskwela</td>
									</tr>
									<tr>
										<td>January 14, 2019 @ 7:00 PM</td>
										<td>PTA Meeting</td>
                                    </tr>
									<tr>
										<td>February 28, 2019 - March 05, 2019</td>
										<td>Last Quarter Exam</td>
									</tr>
									<tr>
										<td>March 03, 2019</td>
										<td>Closing of School Year 2018 - 2019</td>
									</tr>
								</table>
							</div>
						</div>
						</div>
					</div>
				</div>
			</div>	
		</div>	
	</div>
