	<div class="contentpage">
		<div class="row">
			<p>Logs Page information coming soon....</p>
		</div>
	</div>