	<div class="contentpage">
		<div class="row">	
			<div class="eventwidget">
				<div class="contleft">
					<div class="header">
						<p>	
							<i class="far fa-calendar-alt fnt"></i>
							<span>Statement of Account</span>
						</p>
					</div>
				<div class="eventcontent">
                    <div class="cont1">
                        <p><font color="blue" size="5">Balance: Php 1,399.00</font></p>
                    </div>
					<div class="cont3">
						<div class="table-scroll">	
							<div class="table-wrap">	
								<table>
									<tr>
										<th>DATE</th>
										<th>AMOUNT</th>   
									</tr>
									<tr>
										<td>September 12, 2019</td>
										<td>Php 120.00</td>
									</tr>
									<tr>
										<td>September 12, 2019</td>
										<td>Php 120.00</td>
									</tr>
									<tr>
										<td>September 12, 2019</td>
										<td>Php 120.00</td>
                                    </tr>
									<tr>
										<td>September 12, 2019</td>
										<td>Php 120.00</td>
									</tr>
                                    <tr>
										<td><b>TOTAL AMOUNT:</b></td>
										<td><b><font color="green">PHP 1,399.00</font></b></td>
									</tr>
								</table>
							</div>
						</div>
					</div>
                    <div class="cont4">
						<p>Showing 1 to 5 of 250 entries</p>
						<div class="pagination">
							<button class="btn previous">Previous</button>
							<button class="btn active">1</button>
							<button class="btn ">2</button>
							<button class="btn ">3</button>
							<button class="btn ">4</button>
							<button class="btn ">5</button>
							<button class="btn next">Next</button>
					    </div>
				    </div>
				</div>
				</div>
				<div class="contright">
					<div class="innercont1">
						<div class="header">
							<p>	
								<i class="far fa-calendar-alt fnt"></i>
								<span>Breakdown of Fees</span>
							</p>
						</div>
						<div class="eventcontent">
							<div class="table-scroll">	
							<div class="table-wrap">	
								<table>
									<tr>
										<th> </th>
										<th>AMOUNT</th>   
									</tr>
									<tr>
										<td>PTA Fee</td>
										<td>Php 300.00</td>
									</tr>
									<tr>
										<td>Utility Fee</td>
										<td>Php 300.00</td>
									</tr>
									<tr>
										<td>School Paper Fee</td>
										<td>Php 150.00</td>
                                    </tr>
									<tr>
										<td>Organization Fee</td>
										<td>Php 120.00</td>
									</tr>
									<tr>
										<td>Technology (TLE)</td>
										<td>Php 75.00</td>
									</tr>
									<tr>
										<td>Science Fee</td>
										<td>Php 50.00</td>
									</tr>
									<tr>
										<td>Supreme Student Government</td>
										<td>Php 75.00</td>
									</tr>
									<tr>
										<td>Internet Fee</td>
										<td>Php 250.00</td>
									</tr>
                                    <tr>
										<td><b>TOTAL AMOUNT:</b></td>
										<td><b><font color="green">PHP 1,399.00</font></b></td>
									</tr>
								</table>
							</div>
						</div>
						</div>
					</div>
				</div>
			</div>	
		</div>	
	</div>
