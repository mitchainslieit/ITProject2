	<div class="contentpage">
        <div class="row">	
            <div class="widget">	
				<div class="header">	
					<p>	
						<i class="fas fa-book-open fnt"></i>
						<span>Grades</span>
					</p>
					<p>School Year: 2019-2020</p>
				</div>	
				<div class="eventcontent">
					<div class="cont1">
						<p>Name: <span>Rac C. Roswell</span></p>
                        <p>Grade: <span>7 - HOPE</span></p>
					</div>
					<div class="cont2">
						<div class="box1">
							<select>
								<option value="5">5</option>
								<option value="10">10</option>
								<option value="25">25</option>
								<option value="50">50</option>
								<option value="100">100</option>
							</select>
							<span>records per page</span>
						</div>
						<div class="box2">
							<span>Search:</span>
							<input type="" name=""></input>
						</div>
					</div>
					<div class="cont3">
						<div class="table-scroll">	
							<div class="table-wrap">	
								<table>
									<tr>
										<th>Subject</th>
										<th>1st Grading</th>
										<th>2nd Grading</th>
                                        <th>3rd Grading</th>
                                        <th>4th Grading</th>
                                        <th>FINAL GRADE</th>
                                        <th>RATING</th>
									</tr>
									<tr>
										<td>English</td>
										<td>90</td>
										<td>87</td>
                                        <td>88</td>
                                        <td>84</td>
                                        <td>87</td>
                                        <td><b><font color="green">PASSED</font></b></td>
									</tr>
									<tr>
										<td>Mathematics</td>
										<td>67</td>
										<td>75</td>
                                        <td>74</td>
                                        <td>73</td>
                                        <td>65</td>
                                        <td><b><font color="red">FAILED</font></b></td>
									</tr>
									<tr>
										<td>Araling Panlipunan</td>
										<td>67</td>
										<td>75</td>
                                        <td>74</td>
                                        <td>73</td>
                                        <td>65</td>
                                        <td><b><font color="red">FAILED</font></b></td>
                                    </tr>
									<tr>
										<td>Science</td>
										<td>67</td>
										<td>75</td>
                                        <td>74</td>
                                        <td>73</td>
                                        <td>65</td>
                                        <td><b><font color="red">FAILED</font></b></td>
									</tr>
									<tr>
										<td>TLE</td>
										<td>67</td>
										<td>75</td>
                                        <td>74</td>
                                        <td>73</td>
                                        <td>65</td>
                                        <td><b><font color="red">FAILED</font></b></td>
									</tr>
                                    <tr>
										<td>Filipino</td>
										<td>67</td>
										<td>75</td>
                                        <td>74</td>
                                        <td>73</td>
                                        <td>65</td>
                                        <td><b><font color="red">FAILED</font></b></td>
									</tr>
                                    <tr>
										<td>MAPEH</td>
										<td>67</td>
										<td>75</td>
                                        <td>74</td>
                                        <td>73</td>
                                        <td>65</td>
                                        <td><b><font color="red">FAILED</font></b></td>
									</tr>
                                    <tr>
                                        <td>Music</td>
										<td>67</td>
										<td>75</td>
                                        <td>74</td>
                                        <td>73</td>
                                        <td>65</td>
                                        <td><b><font color="red">FAILED</font></b></td>
									</tr>
                                    <tr>
										<td>Arts</td>
										<td>67</td>
										<td>75</td>
                                        <td>74</td>
                                        <td>73</td>
                                        <td>65</td>
                                        <td><b><font color="red">FAILED</font></b></td>
									</tr>
                                    <tr>
										<td>PE</td>
										<td>67</td>
										<td>75</td>
                                        <td>74</td>
                                        <td>73</td>
                                        <td>65</td>
                                        <td><b><font color="red">FAILED</font></b></td>
									</tr>
                                    <tr>
										<td>Health</td>
										<td>67</td>
										<td>75</td>
                                        <td>74</td>
                                        <td>73</td>
                                        <td>65</td>
                                        <td><b><font color="red">FAILED</font></b></td>
									</tr>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
	</div>
</div>