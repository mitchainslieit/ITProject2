	<div class="contentpage">
		<div class="sticky-buttons">
			<button id="print-this">PRINT</button>
		</div>
		<div class="print-container">
			<h2>Bakakeng National High School</h2>
		</div>
	</div>
	<script>
	</script>