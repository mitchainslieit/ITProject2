	<link rel="icon" href="public/images/favicon.png" type="image/x-icon">
	<link href="<?php echo URL; ?>public/styles/style.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/css/cookieconsent.min.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/css/all.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/css/fullcalendar.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/datatables/datatables.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/jquery-ui/jquery-ui.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/ambiance/jquery.ambiance.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/SweetDropDown/jquery.sweet-dropdown.min.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/tooltip/dist/css/tooltipster.bundle.min.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo URL; ?>public/vendors/tooltip/dist/css/plugins/tooltipster/sideTip/themes/tooltipster-sideTip-borderless.min.css"/>


	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/js/jquery-3.3.1.js"></script>
	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/jquery-ui/jquery-ui.js"></script>
 	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/datatables/datatables.min.js"></script>
	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/js/jquery.form-validator.min.js"></script>
	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/js/moment.min.js"></script>
	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/js/fullcalendar.min.js"></script>
	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/SweetDropDown/jquery.sweet-dropdown.min.js"></script>
	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/printThis/printThis.js"></script>
	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/ambiance/jquery.ambiance.js"></script>
	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/sweetalert/sweetalert.js"></script>
	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/tooltip/dist/js/tooltipster.bundle.min.js"></script>
	<script type="text/javascript" src="<?php echo URL; ?>public/vendors/google-chart/loader.js"></script>